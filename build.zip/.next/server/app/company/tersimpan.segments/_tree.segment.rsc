:HL["/_next/static/css/dbd8b077de46e865.css","style"]
:HL["/_next/static/css/0e2ff908933bc981.css","style"]
:HL["/_next/static/css/226f4571965e8b3e.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"company","param":null,"prefetchHints":4192,"slots":{"children":{"name":"tersimpan","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"2z5yb_zHZ9w12Og-G-b60"}
