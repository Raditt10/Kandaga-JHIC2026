:HL["/_next/static/css/dbd8b077de46e865.css","style"]
:HL["/_next/static/css/01a6d894d846ff39.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"company","param":null,"prefetchHints":4192,"slots":{"children":{"name":"tersimpan","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"khx_T12O0bxqN3gPCafsq"}
