:HL["/_next/static/css/dbd8b077de46e865.css","style"]
:HL["/_next/static/css/04561131e8361203.css","style"]
:HL["/_next/static/css/226f4571965e8b3e.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"jurusan","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"b9Zh5yh9p-3hKMf2KgT35"}
