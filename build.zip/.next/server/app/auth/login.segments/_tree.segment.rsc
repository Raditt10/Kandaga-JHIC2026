:HL["/_next/static/css/dbd8b077de46e865.css","style"]
:HL["/_next/static/css/63d78b105009132d.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"auth","param":null,"prefetchHints":4192,"slots":{"children":{"name":"login","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"YFQ859yuWHyW5OhOi5MiH"}
