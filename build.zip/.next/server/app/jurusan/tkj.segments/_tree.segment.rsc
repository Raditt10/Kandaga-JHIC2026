:HL["/_next/static/css/dbd8b077de46e865.css","style"]
:HL["/_next/static/css/3787654504eba557.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4184,"slots":{"children":{"name":"jurusan","param":null,"prefetchHints":4200,"slots":{"children":{"name":"slug","param":{"type":"d","key":"tkj","siblings":[]},"prefetchHints":4196,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"hJzMzPZsN8EKMBCi2kS-v"}
