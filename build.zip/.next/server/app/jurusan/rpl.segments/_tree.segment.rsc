:HL["/_next/static/css/dbd8b077de46e865.css","style"]
:HL["/_next/static/css/aefb7d3b2bb383cc.css","style"]
:HL["/_next/static/css/226f4571965e8b3e.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4184,"slots":{"children":{"name":"jurusan","param":null,"prefetchHints":4200,"slots":{"children":{"name":"slug","param":{"type":"d","key":"rpl","siblings":[]},"prefetchHints":4196,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"baRbW9e5odanovTu3SKbj"}
