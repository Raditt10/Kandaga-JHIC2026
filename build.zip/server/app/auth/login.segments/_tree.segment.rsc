:HL["/_next/static/css/dbd8b077de46e865.css","style"]
:HL["/_next/static/css/aed2bc05539d0fbe.css","style"]
:HL["/_next/static/css/226f4571965e8b3e.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"auth","param":null,"prefetchHints":4192,"slots":{"children":{"name":"login","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"N2UZ5P4NB_Jn6RBnr1K8M"}
