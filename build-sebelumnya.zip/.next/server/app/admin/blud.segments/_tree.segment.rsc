:HL["/_next/static/css/dbd8b077de46e865.css","style"]
:HL["/_next/static/css/7d8b250903560186.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"admin","param":null,"prefetchHints":4192,"slots":{"children":{"name":"blud","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"pFyGjVpkvrftYtv9aj7NS"}
